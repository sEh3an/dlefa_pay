<?PHP
// DLEFA Pay Gateways Configurations
$pay_config = array (
'module_title' => 'پلاگین پرداخت آنلاین همیار دیتالایف',
'fish_order' => '20',
'mellat_on' => '0',
'mellat_terminalid' => '',
'mellat_username' => '',
'mellat_password' => '',
'zarinpal_on' => '0',
'zarinpal_MerchantID' => '',
'sms_on' => '0',
'sms_uname' => '',
'sms_pass' => '',
'sms_from' => '',
'sms_text' => 'سلام
خرید شما با کد رهگیری %pay_code% ثبت شد.',
'sms_admin_on' => '0',
'sms_admin' => '',
'admin_text' => 'سلام
فاکتوری در سایت ثبت گردید.',
);
?>